import sqlite3
import random
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters
)

TOKEN = "8480356172:AAGOzKTmkKpA03ripwPql8lKL7PsUeeGgAY"
ADMIN_ID = 123456789
REWARD = 0.002
REF_BONUS = 0.001
MIN_WITHDRAW = 2.0

# ---------------- DATABASE ----------------
conn = sqlite3.connect("microtask.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    balance REAL DEFAULT 0,
    referrals INTEGER DEFAULT 0,
    referred_by INTEGER
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    link TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    task_id INTEGER,
    screenshot TEXT,
    status TEXT DEFAULT 'pending'
)
""")

conn.commit()

# ---------------- DEFAULT TASKS ----------------
tasks_list = [
    ("TikTok Follow", "https://www.tiktok.com/@shantobhaiya2.0"),
    ("Instagram Follow", "https://www.instagram.com/cliffeatdinham/"),
    ("Facebook Follow", "https://www.facebook.com/hasan.shanto4/")
]

for title, link in tasks_list:
    cursor.execute("SELECT * FROM tasks WHERE link=?", (link,))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO tasks (title, link) VALUES (?, ?)", (title, link))
conn.commit()

# ---------------- MAIN MENU ----------------
def main_menu():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("➕ Start Task", callback_data="task"),
            InlineKeyboardButton("💰 Balance", callback_data="balance")
        ],
        [
            InlineKeyboardButton("👥 Referrals", callback_data="referral"),
            InlineKeyboardButton("🏧 Withdraw", callback_data="withdraw")
        ]
    ])

# ---------------- START ----------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    args = context.args

    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    if not cursor.fetchone():
        referred_by = int(args[0]) if args else None
        cursor.execute("INSERT INTO users (user_id, referred_by) VALUES (?, ?)",
                       (user_id, referred_by))
        conn.commit()

        if referred_by:
            cursor.execute("UPDATE users SET balance=balance+?, referrals=referrals+1 WHERE user_id=?",
                           (REF_BONUS, referred_by))
            conn.commit()

    await update.message.reply_text(
        "💸 Welcome!\nEarn $0.002 per task.",
        reply_markup=main_menu()
    )

# ---------------- TASK ----------------
async def task(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id

    cursor.execute("SELECT * FROM tasks")
    tasks = cursor.fetchall()
    task = random.choice(tasks)

    task_id = task[0]
    context.user_data["task_id"] = task_id

    # Check approved
    cursor.execute("""
    SELECT * FROM submissions 
    WHERE user_id=? AND task_id=? AND status='approved'
    """, (user_id, task_id))
    if cursor.fetchone():
        await query.message.reply_text("✅ You already completed this task.")
        return

    # Check pending
    cursor.execute("""
    SELECT * FROM submissions 
    WHERE user_id=? AND task_id=? AND status='pending'
    """, (user_id, task_id))
    if cursor.fetchone():
        await query.message.reply_text("⏳ This task is still pending approval.")
        return

    keyboard = [[InlineKeyboardButton("📸 Submit Screenshot", callback_data="submit")]]

    await query.message.reply_text(
        f"📌 Task: {task[1]}\n💵 Reward: ${REWARD}\n\n👉 {task[2]}",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ---------------- SUBMIT BUTTON ----------------
async def submit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.message.reply_text(
        "📸 Please send your screenshot now.\nAfter sending, wait for admin approval."
    )

# ---------------- RECEIVE SCREENSHOT ----------------
async def receive_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    task_id = context.user_data.get("task_id")

    if not task_id:
        await update.message.reply_text("⚠ Please click Start Task first.")
        return

    file_id = update.message.photo[-1].file_id

    cursor.execute("""
    INSERT INTO submissions (user_id, task_id, screenshot)
    VALUES (?, ?, ?)
    """, (user_id, task_id, file_id))
    conn.commit()

    submission_id = cursor.lastrowid

    keyboard = [
        [
            InlineKeyboardButton("✅ Approve", callback_data=f"approve_{submission_id}"),
            InlineKeyboardButton("❌ Reject", callback_data=f"reject_{submission_id}")
        ]
    ]

    await context.bot.send_photo(
        ADMIN_ID,
        file_id,
        caption=f"New Submission\nUser: {user_id}",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

    await update.message.reply_text(
        "✅ Screenshot received!\n⏳ Status: Pending Admin Approval."
    )

# ---------------- ADMIN ACTION ----------------
async def admin_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        return

    action, submission_id = query.data.split("_")
    submission_id = int(submission_id)

    cursor.execute("SELECT user_id FROM submissions WHERE id=?", (submission_id,))
    result = cursor.fetchone()

    if not result:
        return

    user_id = result[0]

    if action == "approve":
        cursor.execute("UPDATE users SET balance=balance+? WHERE user_id=?",
                       (REWARD, user_id))
        cursor.execute("UPDATE submissions SET status='approved' WHERE id=?",
                       (submission_id,))
        conn.commit()

        await context.bot.send_message(
            user_id,
            f"🎉 Task Approved!\n💰 ${REWARD} added to your balance."
        )

    else:
        cursor.execute("UPDATE submissions SET status='rejected' WHERE id=?",
                       (submission_id,))
        conn.commit()

        await context.bot.send_message(
            user_id,
            "❌ Task Rejected.\nPlease make sure you complete correctly."
        )

    await query.edit_message_reply_markup(None)

# ---------------- BALANCE ----------------
async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    cursor.execute("SELECT balance FROM users WHERE user_id=?",
                   (update.callback_query.from_user.id,))
    bal = cursor.fetchone()[0]

    await update.callback_query.message.reply_text(
        f"💰 Your Balance: ${round(bal,3)}"
    )

# ---------------- REFERRAL ----------------
async def referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    user_id = update.callback_query.from_user.id
    link = f"https://t.me/{context.bot.username}?start={user_id}"

    await update.callback_query.message.reply_text(
        f"👥 Your Referral Link:\n{link}\nEarn ${REF_BONUS} per referral."
    )

# ---------------- WITHDRAW ----------------
async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    cursor.execute("SELECT balance FROM users WHERE user_id=?",
                   (update.callback_query.from_user.id,))
    bal = cursor.fetchone()[0]

    if bal < MIN_WITHDRAW:
        await update.callback_query.message.reply_text(
            f"Minimum withdraw is ${MIN_WITHDRAW}"
        )
        return

    await context.bot.send_message(
        ADMIN_ID,
        f"Withdraw Request\nUser: {update.callback_query.from_user.id}\nAmount: ${bal}"
    )

    await update.callback_query.message.reply_text(
        "✅ Withdrawal request sent."
    )

# ---------------- RUN ----------------
app = ApplicationBuilder().token(TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(task, pattern="task"))
app.add_handler(CallbackQueryHandler(balance, pattern="balance"))
app.add_handler(CallbackQueryHandler(referral, pattern="referral"))
app.add_handler(CallbackQueryHandler(withdraw, pattern="withdraw"))
app.add_handler(CallbackQueryHandler(submit, pattern="submit"))
app.add_handler(CallbackQueryHandler(admin_action, pattern="approve_|reject_"))
app.add_handler(MessageHandler(filters.PHOTO, receive_photo))

print("Bot Running...")
app.run_polling()
